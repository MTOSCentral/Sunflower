#MintLog For Mint/Central
import sqlite3
conn =sqlite3.connect('database\\history.sql', check_same_thread=False)
cursor = conn.cursor()
VER="1.0.0"
class History:
    def __init__(self):
        global conn
        sqlstr='CREATE TABLE IF NOT EXISTS history \
        ("Year" TEXT,"Month" TEXT,"Day" TEXT,"Action" TEXT,"Money" TEXT,"Adult" TEXT,"Child" TEXT,"Note" TEXT,"CurrentValue" TEXT)'
        self.curs = conn.cursor()
        self.curs.execute(sqlstr)
        conn.commit()
    def makehistory(self,action,year,month,date,money,note,who,child,currentvalue):
        global conn
        sqlstr=f'insert into history values("{year}","{month}","{date}","{action}","{money}","{who}","{child}","{note}","{currentvalue}")'
        self.curs.execute(sqlstr)
        conn.commit()

    def version(self):
        return VER