#OOBE For Meow Tech Codenamed Central
from flask import Blueprint,session,render_template,Response,request,flash,url_for
import random
import string
import shutil
from werkzeug.utils import redirect
from hashing import Hashing
import sqlite3
from flask import json
from datetime import datetime
from flask import jsonify
apimodule=Blueprint("api", __name__, static_folder="static", template_folder="template")
conn =sqlite3.connect('database\\users.sql', check_same_thread=False)
cursor = conn.cursor()
year = datetime.now().strftime('%Y')
hasher=Hashing()
links=['/','/setup']
apis={'child':['lala3','child'],'adult':['lala','adult']}
with open("branding\\branding.json") as file:
    brandinfo = json.load(file)
    productname = brandinfo["Vendor"]+" "+brandinfo["ProductName"]
    lc=brandinfo["License"]
    print(productname)
    file.close()
with open("lang\\zh-HK.json",encoding="utf-8") as file:
    lang = json.load(file)
    file.close()
with open(lc,encoding="utf-8") as file:
    license1=file.readlines()
    file.close()
def genapi(user,passwd):
    hasher=Hashing()
    sqlstr='select * from users'
    cur=conn.execute(sqlstr)
    rows=cur.fetchall()
    cor=False
    for row in rows:
        if hasher.check(passwd,row[1]) and user == row[0]:
            global apis
            #session["user"] = user
            #session["role"] = row[2]
            #gensession()
            cor=True
            letters = string.ascii_letters
            letters=letters+string.digits
            apikey = ''.join(random.choice(letters) for i in range(64))
            apis[apikey]=[user,row[2]]
            #{'APIKEY':[Username,Role]}
            print("[Debug Information] API KEY LIST = "+str(apis))
            return {'value':apikey}
        #else:
            #pass
    if not cor:
        return {'value':'0x00000'}

@apimodule.route('/getkey/<usrname>/<passwd>')
def genapikey(usrname,passwd):
    return jsonify(genapi(usrname,passwd))

@apimodule.route('/addmoney/<apikey>/<var1>/<var2>')
def addmoney(apikey,var1,var2):
    global apis
    if apikey in apis:
        if apis[apikey][1] == "adult":
            #Add Money
            pass
        else:
            return jsonify({"value":"0x00001"})
            #apis.pop(apikey)
    else:
        return jsonify({'value':'0x00002'})
